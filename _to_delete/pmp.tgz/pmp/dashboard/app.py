"""Streamlit dashboard. Reads a static snapshot (dashboard/demo_data) so it works with no AWS,
no database and no API. If API_URL is set and reachable, the "Try a reading" form calls it live."""

from __future__ import annotations

import json
import os
from pathlib import Path

import altair as alt
import pandas as pd
import streamlit as st

DEMO = Path(os.getenv("DEMO_DIR", Path(__file__).parent / "demo_data"))
API_URL = os.getenv("API_URL", "").rstrip("/")
RISK_COLORS = {"HIGH": "#C23B22", "MEDIUM": "#E39B1B", "LOW": "#5B8DB8"}
BLUE, GREY = "#1F5FBF", "#8A94A3"
SENSOR_COLORS = {"pressure": "#1F5FBF", "rotation": "#7A8794", "vibration": "#0E8A7B", "voltage": "#8E5BB5"}

st.set_page_config(page_title="Predictive maintenance", page_icon=None, layout="wide")


@st.cache_data
def load():
    def csv(name, **kw):
        return pd.read_csv(DEMO / name, **kw)

    return {
        "overview": json.loads((DEMO / "overview.json").read_text()),
        "summary": json.loads((DEMO / "summary.json").read_text()),
        "decisions": json.loads((DEMO / "decisions.json").read_text()),
        "risk": csv("risk_table.csv", parse_dates=["timestamp"]),
        "history": csv("history.csv", parse_dates=["timestamp"]),
        "failures": csv("failures.csv", parse_dates=["timestamp"]),
        "drift": csv("drift.csv"),
        "timeline": csv("drift_timeline.csv", parse_dates=["day"]),
        "comparison": csv("comparison.csv"),
        "calibration": csv("calibration.csv"),
        "cost": csv("cost_curve.csv"),
    }


if not (DEMO / "overview.json").exists():
    st.error("No snapshot found. Run `make demo` to generate dashboard/demo_data.")
    st.stop()

d = load()
ov, summary = d["overview"], d["summary"]

st.sidebar.title("Predictive maintenance")
page = st.sidebar.radio("Page", ["Overview", "Machine", "Monitoring", "Model", "Cost"], label_visibility="collapsed")
st.sidebar.caption(f"Model v{ov['model_version']} ({ov['model_name']})")
st.sidebar.caption(f"Data up to {ov['data']['last_timestamp']}")
if ov.get("synthetic_data"):
    st.sidebar.warning("Synthetic data. Results say nothing about real machines.")

if page == "Overview":
    st.title("Which machines should we inspect today?")
    c = st.columns(4)
    c[0].metric("Machines tracked", ov["data"]["machines"])
    c[1].metric("High risk", ov["high_risk"])
    c[2].metric("Medium risk", ov["medium_risk"])
    c[3].metric("Data drift", "Detected" if ov["drift_detected"] else "None", ", ".join(ov["drifted_variables"]) or None, delta_color="off")
    risk = d["risk"].copy()
    risk["probability"] = (risk["failure_probability"] * 100).round(1)
    top = risk.head(15)
    chart = (
        alt.Chart(top)
        .mark_bar(cornerRadiusEnd=3)
        .encode(
            y=alt.Y("machine_id:N", sort="-x", title=None),
            x=alt.X("probability:Q", title="Failure probability in the next 24 h (%)"),
            color=alt.Color("risk_level:N", scale=alt.Scale(domain=list(RISK_COLORS), range=list(RISK_COLORS.values())), title="Risk"),
            tooltip=["machine_id", "probability", "risk_level", "top_factor"],
        )
        .properties(height=380)
    )
    st.altair_chart(chart, use_container_width=True)
    st.dataframe(
        risk[["machine_id", "risk_level", "probability", "top_factor"]].rename(
            columns={"probability": "probability (%)", "top_factor": "main factor"}
        ),
        hide_index=True,
        use_container_width=True,
        height=260,
    )

elif page == "Machine":
    st.title("Machine detail")
    m = st.selectbox("Machine", d["risk"]["machine_id"].tolist())
    h = d["history"][d["history"]["machine_id"] == m]
    fails = d["failures"][d["failures"]["machine_id"] == m]
    row = d["risk"][d["risk"]["machine_id"] == m].iloc[0]
    c = st.columns(3)
    c[0].metric("Risk level", row["risk_level"])
    c[1].metric("Failure probability (24 h)", f"{row['failure_probability']:.1%}")
    c[2].metric("Main factor", row["top_factor"] or "n/a")
    line = (
        alt.Chart(h)
        .mark_line(color=BLUE)
        .encode(x=alt.X("timestamp:T", title=None), y=alt.Y("failure_probability:Q", title="Failure probability"))
    )
    marks = (
        alt.Chart(fails[fails["timestamp"] >= h["timestamp"].min()])
        .mark_rule(color=RISK_COLORS["HIGH"], strokeDash=[4, 3])
        .encode(x="timestamp:T")
    )
    st.altair_chart((line + marks).properties(height=220, title="Risk over the last 7 days (dashed = failure)"), use_container_width=True)
    sensors = h.melt(["timestamp"], ["voltage", "rotation", "pressure", "vibration"], "sensor", "value")
    st.altair_chart(
        alt.Chart(sensors)
        .mark_line(color=GREY)
        .encode(
            x=alt.X("timestamp:T", title=None),
            y=alt.Y("value:Q", scale=alt.Scale(zero=False), title=None),
            row=alt.Row("sensor:N", title=None),
        )
        .properties(height=90),
        use_container_width=True,
    )
    if API_URL:
        with st.expander("Try a reading against the live API"):
            import requests

            vals = {k: st.number_input(k, value=float(h[k].iloc[-1])) for k in ("voltage", "rotation", "pressure", "vibration")}
            if st.button("Score"):
                try:
                    r = requests.post(f"{API_URL}/predict", json={"machine_id": m, **vals}, timeout=5)
                    st.json(r.json())
                except Exception as exc:
                    st.warning(f"API not reachable ({exc}). The snapshot above does not need it.")

elif page == "Monitoring":
    st.title("Data drift and model decisions")
    tl = d["timeline"]
    base = (
        alt.Chart(tl)
        .mark_line()
        .encode(
            x=alt.X("day:T", title=None),
            y=alt.Y("psi:Q", title="PSI vs training period"),
            color=alt.Color("variable:N", title="Sensor", scale=alt.Scale(domain=list(SENSOR_COLORS), range=list(SENSOR_COLORS.values()))),
        )
    )
    rule = alt.Chart(pd.DataFrame({"y": [0.2]})).mark_rule(color=RISK_COLORS["HIGH"], strokeDash=[5, 4]).encode(y="y:Q")
    st.altair_chart(
        (base + rule).properties(height=300, title="Daily PSI per sensor (dashed = alert threshold 0.2)"), use_container_width=True
    )
    st.dataframe(d["drift"].assign(ks_pvalue=lambda x: x["ks_pvalue"].map("{:.2g}".format)), hide_index=True, use_container_width=True)
    st.subheader("Champion / challenger decisions")
    if d["decisions"]:
        for dec in d["decisions"]:
            st.markdown(
                f"**{'Promoted' if dec['promoted'] else 'Refused'}** (v{dec['challenger_version']}, trigger: {dec.get('trigger', 'n/a')}): {dec['reason']}"
            )
            if dec.get("champion_cost"):
                st.caption(
                    f"Total cost on the same unseen window: champion {dec['champion_cost']:,.0f} EUR vs challenger {dec['challenger_cost']:,.0f} EUR (hypothetical costs)."
                )
    else:
        st.info("No decision yet.")

elif page == "Model":
    st.title("Model comparison and calibration")
    st.caption("Chronological split: train, calibration, threshold, test. Metrics below are on the untouched test block.")
    st.dataframe(d["comparison"].round(3), hide_index=True, use_container_width=True)
    cal = d["calibration"]
    diag = pd.DataFrame({"x": [0, cal["predicted"].max()], "y": [0, cal["predicted"].max()]})
    pts = (
        alt.Chart(cal)
        .mark_circle(size=70, color=BLUE)
        .encode(
            x=alt.X("predicted:Q", title="Predicted probability"),
            y=alt.Y("observed:Q", title="Observed frequency"),
            tooltip=["predicted", "observed", "n"],
        )
    )
    st.altair_chart(
        (pts + alt.Chart(diag).mark_line(color=GREY, strokeDash=[4, 3]).encode(x="x:Q", y="y:Q")).properties(
            height=300, title="Calibration (on the diagonal = well calibrated)"
        ),
        use_container_width=True,
    )
    f = summary["final_test"]
    c = st.columns(4)
    c[0].metric("PR-AUC", f"{f['pr_auc']:.3f}", f"baseline {f['baseline_pr_auc']:.3f}", delta_color="off")
    c[1].metric("Recall", f"{f['recall']:.1%}")
    c[2].metric("Precision", f"{f['precision']:.1%}")
    c[3].metric(f"Precision, top {f['n_per_day']} per day", f"{f['precision_at_n']:.1%}")

else:
    st.title("Decision threshold in euros")
    st.warning("The costs are hypothetical assumptions (docs/cost_assumptions.md), not real figures.")
    cost = d["cost"]
    thr = summary["threshold"]
    line = (
        alt.Chart(cost)
        .mark_line(color=BLUE)
        .encode(x=alt.X("threshold:Q", title="Probability threshold"), y=alt.Y("cost:Q", title="Total cost (EUR)"))
    )
    pick = alt.Chart(pd.DataFrame({"x": [thr]})).mark_rule(color=RISK_COLORS["HIGH"]).encode(x="x:Q")
    st.altair_chart(
        (line + pick).properties(height=320, title="Total cost on the threshold block (red = chosen threshold)"), use_container_width=True
    )
    f = summary["final_test"]
    c = st.columns(3)
    c[0].metric("Model, test block", f"{f['total_cost']:,.0f} EUR")
    c[1].metric("Never inspect", f"{f['cost_do_nothing']:,.0f} EUR")
    c[2].metric("Inspect everything", f"{f['cost_inspect_all']:,.0f} EUR")
    st.caption(f"Costs used: {summary['costs']}")
